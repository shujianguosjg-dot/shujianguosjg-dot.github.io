# Website media · NBS + VLA

These are resized, web-optimized exports of the evidence-backed source files, not AI-generated predictions or altered numerical charts.

In GitHub repo — upload `site-media.zip` into repository root; the GitHub Actions workflow unpacks only `public/media/*` files before `npm run build` for static Pages deployment.

- ETH3D material: CC BY-NC-SA 4.0, noncommercial use with attribution (https://eth3d.ethz.ch/).
- Middlebury 2021 stereo: publish with requested citation (https://vision.middlebury.edu/stereo/data/).
- LIBERO: simulated robotics episodes; source simulator and model must be credited.

Do not claim statistically significant VLA effects; all VLA success rates refer to the 100-episode screening protocol.
